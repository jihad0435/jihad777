package com.jihad.businessmanager;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db;
    LinearLayout root, content, top;
    boolean bn = true;
    String selectedCustomer = null;
    int ink = Color.rgb(28, 39, 56), green = Color.rgb(20, 135, 91), red = Color.rgb(190, 55, 62), blue = Color.rgb(45, 93, 180);

    String s(String b, String e){ return bn ? b : e; }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); db = new DB(this); showHome();
    }
    TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size);
        t.setTextColor(ink); if(bold)t.setTypeface(null, Typeface.BOLD);
        t.setPadding(4,6,4,6); return t;
    }
    Button button(String label, Runnable r) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setOnClickListener(v -> r.run()); return b;
    }
    EditText field(String hint, String value) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setText(value == null ? "" : value);
        e.setHint(hint); e.setPadding(18,8,18,8); return e;
    }
    void frame(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(246,248,252));
        top = new LinearLayout(this); top.setPadding(12,6,12,6); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = text(title,20,true); heading.setTextColor(Color.WHITE); heading.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));
        top.setBackgroundColor(ink); top.addView(heading);
        top.addView(button(bn ? "EN" : "বাংলা", () -> {bn=!bn; showHome();}));
        root.addView(top);
        ScrollView sc = new ScrollView(this); content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(16,12,16,22);
        sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav = new LinearLayout(this); nav.setPadding(4,4,4,4); nav.setBackgroundColor(Color.WHITE);
        nav.addView(button(s("হোম","Home"), this::showHome),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(button(s("গ্রাহক","Customers"), this::showCustomers),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(button(s("নতুন সেল","Add sale"), this::addSale),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(button(s("ব্যাকআপ","Backup"), this::backupMenu),new LinearLayout.LayoutParams(0,-2,1));
        root.addView(nav); setContentView(root);
    }
    void add(View v){ content.addView(v); }
    void gap(){ View v=new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1,8)); add(v); }
    void card(String title, String value, int color) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(16,12,16,12);
        box.setBackgroundColor(Color.WHITE); TextView a=text(title,14,false), b=text(value,24,true); b.setTextColor(color);
        box.addView(a); box.addView(b); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,5,0,5); box.setLayoutParams(lp); add(box);
    }
    String money(long n){return "৳ "+String.format(Locale.US,"%,d",n);}
    long[] totals(String dateFilter) {
        long sales=0, paid=0;
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0), COALESCE(SUM(initial_paid),0) FROM sales "+(dateFilter==null?"":"WHERE sale_date=?"), dateFilter==null?null:new String[]{dateFilter});
        if(c.moveToFirst()){sales=c.getLong(0);paid=c.getLong(1);} c.close();
        Cursor p=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments"+(dateFilter==null?"":" WHERE pay_date=?"),dateFilter==null?null:new String[]{dateFilter});
        if(p.moveToFirst())paid+=p.getLong(0);p.close();return new long[]{sales,paid,sales-paid};
    }
    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    void showHome(){
        frame(s("Jihad Business Manager","Jihad Business Manager"));
        long[] all=totals(null), day=totals(today());
        add(text(s("আপনার ব্যবসার হিসাব","Your business overview"),17,true)); gap();
        card(s("আজকের বিক্রয়","Today's sales"),money(day[0]),blue);
        card(s("আজ আদায় (আজকের এন্ট্রি)","Payments received today"),money(todaysPayments()),green);
        card(s("মোট বিক্রয়","Total sales"),money(all[0]),blue);
        card(s("মোট পেমেন্ট","Total payments"),money(all[1]),green);
        card(s("মোট বকেয়া","Total due"),money(all[2]),all[2]>0?red:green);
        card(s("গ্রাহক সংখ্যা","Customers"),String.valueOf(customerCount()),ink);
        gap(); add(button(s("＋ নতুন সেল যোগ করুন","＋ Add new sale"),this::addSale));
        add(button(s("👥 গ্রাহকের তালিকা","👥 Customer list"),this::showCustomers));
    }
    long todaysPayments(){
        long x=0; Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(initial_paid),0) FROM sales WHERE sale_date=?",new String[]{today()});if(c.moveToFirst())x=c.getLong(0);c.close();
        c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments WHERE pay_date=?",new String[]{today()});if(c.moveToFirst())x+=c.getLong(0);c.close();return x;
    }
    int customerCount(){Cursor c=db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM customers WHERE archived=0",null);int n=c.moveToFirst()?c.getInt(0):0;c.close();return n;}
    void showCustomers(){showCustomerList("");}
    void showCustomerList(String query){
        frame(s("গ্রাহক তালিকা","Customers"));
        EditText search=field(s("নাম বা ইউজার নেম খুঁজুন","Search name or username"),query); add(search);
        add(button(s("সার্চ","Search"),()->showCustomerList(search.getText().toString().trim())));
        add(button(s("＋ নতুন গ্রাহক / সেল","＋ New customer / sale"),this::addSale)); gap();
        String sql="SELECT c.username,c.name,COALESCE(SUM(s.amount),0),COALESCE(SUM(s.initial_paid),0),c.archived FROM customers c LEFT JOIN sales s ON s.username=c.username WHERE (c.username LIKE ? OR c.name LIKE ?) AND c.archived=0 GROUP BY c.username,c.name,c.archived ORDER BY c.name";
        Cursor c=db.getReadableDatabase().rawQuery(sql,new String[]{"%"+query+"%","%"+query+"%"});
        if(!c.moveToFirst()){add(text(s("কোনো গ্রাহক পাওয়া যায়নি","No customers found"),15,false));}
        else do{
            String u=c.getString(0), name=c.getString(1); long sales=c.getLong(2), paid=c.getLong(3)+paymentSum(u), due=sales-paid;
            LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(12,8,12,8);box.setBackgroundColor(Color.WHITE);
            box.addView(text((name==null||name.isEmpty()?u:name)+"  ·  "+u,17,true));
            box.addView(text(s("সেল: ","Sales: ")+money(sales)+"   "+s("বাকি: ","Due: ")+money(due),14,false));
            box.addView(button(s("বিস্তারিত / এডিট","Details / Edit"),()->customerDetails(u)));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,5,0,5);box.setLayoutParams(lp);add(box);
        }while(c.moveToNext()); c.close();
    }
    long paymentSum(String u){long n=0;Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments WHERE username=?",new String[]{u});if(c.moveToFirst())n=c.getLong(0);c.close();return n;}
    void addSale(){
        frame(s("নতুন সেল","Add sale"));
        EditText username=field(s("ইউজার নেম (আবশ্যক)","Username (required)"),"");
        EditText name=field(s("গ্রাহকের নাম (ঐচ্ছিক)","Customer name (optional)"),"");
        EditText date=field(s("তারিখ YYYY-MM-DD","Date YYYY-MM-DD"),today());
        EditText amount=field(s("সেলের মোট টাকা","Sale amount"),"");
        EditText paid=field(s("এখন কত টাকা পেয়েছেন","Paid now"),"0");
        EditText note=field(s("নোট (ঐচ্ছিক)","Note (optional)"),"");
        add(text(s("একই ইউজার নেম দিলে আগের গ্রাহকের সঙ্গে নতুন সেল যোগ হবে।","Same username adds a sale to the existing customer."),14,false));
        for(EditText e:new EditText[]{username,name,date,amount,paid,note})add(e);
        add(button(s("সেল সংরক্ষণ করুন","Save sale"),()->{
            String u=username.getText().toString().trim(), nm=name.getText().toString().trim(), dt=date.getText().toString().trim();
            long a=parse(amount.getText().toString()), p=parse(paid.getText().toString());
            if(u.isEmpty()||a<=0||p<0||p>a||!validDate(dt)){toast(s("ইউজার নেম, সঠিক তারিখ ও টাকার পরিমাণ দিন। পেমেন্ট সেলের চেয়ে বেশি হতে পারবে না।","Enter username, valid date and amount. Payment cannot exceed sale amount."));return;}
            SQLiteDatabase w=db.getWritableDatabase();
            Cursor exists=w.rawQuery("SELECT username FROM customers WHERE username=?",new String[]{u});
            boolean has=exists.moveToFirst();exists.close();
            if(has) w.execSQL("UPDATE customers SET name=CASE WHEN ?='' THEN name ELSE ? END WHERE username=?",new Object[]{nm,nm,u});
            else w.execSQL("INSERT INTO customers(username,name,archived) VALUES(?,?,0)",new Object[]{u,nm});
            w.execSQL("INSERT INTO sales(username,sale_date,amount,initial_paid,note) VALUES(?,?,?,?,?)",new Object[]{u,dt,a,p,note.getText().toString().trim()});
            toast(s("সেল সংরক্ষণ হয়েছে","Sale saved"));customerDetails(u);
        }));
    }
    long parse(String x){try{return Long.parseLong(x.trim().replace(",","").replace("৳",""));}catch(Exception e){return -1;}}
    boolean validDate(String d){try{new SimpleDateFormat("yyyy-MM-dd",Locale.US).setLenient(false);SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setLenient(false);f.parse(d);return d.length()==10;}catch(Exception e){return false;}}
    void customerDetails(String u){
        frame(s("গ্রাহকের হিসাব","Customer account"));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT username,name FROM customers WHERE username=?",new String[]{u});
        if(!c.moveToFirst()){c.close();showCustomers();return;}String nm=c.getString(1);c.close();
        long[] t=customerTotals(u);
        add(text((nm==null||nm.isEmpty()?u:nm)+"  (@"+u+")",20,true));
        card(s("মোট সেল","Total sales"),money(t[0]),blue);card(s("মোট পেমেন্ট","Total paid"),money(t[1]),green);card(s("বাকি","Due"),money(t[2]),t[2]>0?red:green);
        add(button(s("✏️ গ্রাহকের নাম / ইউজার নেম এডিট","✏️ Edit customer"),()->editCustomer(u)));
        add(button(s("＋ নতুন সেল যোগ করুন","＋ Add another sale"),()->addSale()));
        add(button(s("💵 পেমেন্ট গ্রহণ করুন","💵 Receive payment"),()->addPayment(u)));
        add(text(s("সেলের ইতিহাস","Sales history"),18,true));
        Cursor sc=db.getReadableDatabase().rawQuery("SELECT id,sale_date,amount,initial_paid,note FROM sales WHERE username=? ORDER BY sale_date DESC,id DESC",new String[]{u});
        if(!sc.moveToFirst())add(text(s("এখনো কোনো সেল নেই","No sales yet"),14,false));
        else do{
            int id=sc.getInt(0);String dt=sc.getString(1), note=sc.getString(4);long a=sc.getLong(2),p=sc.getLong(3);
            LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(10,8,10,8);box.setBackgroundColor(Color.WHITE);
            box.addView(text(dt+"  |  "+money(a),16,true));
            box.addView(text(s("প্রথম পেমেন্ট: ","Initial payment: ")+money(p)+"  ·  "+s("বাকি: ","Due: ")+money(a-p),14,false));
            if(note!=null&&!note.isEmpty())box.addView(text(note,13,false));
            LinearLayout row=new LinearLayout(this);row.addView(button(s("এডিট","Edit"),()->editSale(id)),new LinearLayout.LayoutParams(0,-2,1));
            row.addView(button(s("ডিলিট","Delete"),()->confirmDeleteSale(id,u)),new LinearLayout.LayoutParams(0,-2,1));box.addView(row);add(box);
        }while(sc.moveToNext());sc.close();
        add(text(s("পেমেন্টের ইতিহাস","Payment history"),18,true));
        Cursor pc=db.getReadableDatabase().rawQuery("SELECT id,pay_date,amount,note FROM payments WHERE username=? ORDER BY pay_date DESC,id DESC",new String[]{u});
        if(!pc.moveToFirst())add(text(s("অতিরিক্ত পেমেন্ট নেই","No additional payments"),14,false));
        else do{int id=pc.getInt(0);String dt=pc.getString(1),note=pc.getString(3);long a=pc.getLong(2);
            LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(10,6,10,6);box.setBackgroundColor(Color.WHITE);
            box.addView(text(dt+"  |  +"+money(a),15,true));if(note!=null&&!note.isEmpty())box.addView(text(note,13,false));
            LinearLayout row=new LinearLayout(this);row.addView(button(s("এডিট","Edit"),()->editPayment(id,u)),new LinearLayout.LayoutParams(0,-2,1));row.addView(button(s("ডিলিট","Delete"),()->confirmDeletePayment(id,u)),new LinearLayout.LayoutParams(0,-2,1));box.addView(row);add(box);
        }while(pc.moveToNext());pc.close();
        gap();add(button(s("📦 আর্কাইভ করুন","📦 Archive customer"),()->archiveCustomer(u)));
        add(button(s("🗑️ স্থায়ীভাবে ডিলিট","🗑️ Permanently delete"),()->deleteCustomer(u)));
    }
    long[] customerTotals(String u){
        long sales=0,paid=0;Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0),COALESCE(SUM(initial_paid),0) FROM sales WHERE username=?",new String[]{u});
        if(c.moveToFirst()){sales=c.getLong(0);paid=c.getLong(1);}c.close();paid+=paymentSum(u);return new long[]{sales,paid,sales-paid};
    }
    void editCustomer(String u){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM customers WHERE username=?",new String[]{u});String old=c.moveToFirst()?c.getString(0):"";c.close();
        frame(s("গ্রাহক এডিট","Edit customer"));EditText user=field(s("ইউজার নেম","Username"),u),name=field(s("নাম","Name"),old);add(user);add(name);
        add(button(s("পরিবর্তন সংরক্ষণ","Save changes"),()->{String nu=user.getText().toString().trim();if(nu.isEmpty()){toast("Username required");return;}
            if(!nu.equals(u)){Cursor x=db.getReadableDatabase().rawQuery("SELECT username FROM customers WHERE username=?",new String[]{nu});boolean exists=x.moveToFirst();x.close();if(exists){toast(s("এই ইউজার নেম আগে থেকেই আছে","Username already exists"));return;}}
            SQLiteDatabase w=db.getWritableDatabase();w.execSQL("UPDATE customers SET username=?,name=? WHERE username=?",new Object[]{nu,name.getText().toString().trim(),u});
            w.execSQL("UPDATE sales SET username=? WHERE username=?",new Object[]{nu,u});w.execSQL("UPDATE payments SET username=? WHERE username=?",new Object[]{nu,u});customerDetails(nu);
        }));
    }
    void addPayment(String u){
        frame(s("পেমেন্ট গ্রহণ","Receive payment"));long[] t=customerTotals(u);
        add(text(s("বর্তমান বাকি: ","Current due: ")+money(t[2]),18,true));
        EditText amount=field(s("কত টাকা পেয়েছেন","Amount received"),"");EditText date=field(s("তারিখ YYYY-MM-DD","Date YYYY-MM-DD"),today());EditText note=field(s("নোট (ঐচ্ছিক)","Note (optional)"),"");
        add(amount);add(date);add(note);
        add(button(s("পেমেন্ট সংরক্ষণ","Save payment"),()->{long a=parse(amount.getText().toString());String d=date.getText().toString().trim();
            if(a<=0||a>t[2]||!validDate(d)){toast(s("সঠিক টাকা ও তারিখ দিন। বাকি টাকার বেশি পেমেন্ট দেওয়া যাবে না।","Enter valid amount/date. Payment cannot exceed current due."));return;}
            db.getWritableDatabase().execSQL("INSERT INTO payments(username,pay_date,amount,note) VALUES(?,?,?,?)",new Object[]{u,d,a,note.getText().toString().trim()});
            customerDetails(u);
        }));
    }
    void editSale(int id){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT username,sale_date,amount,initial_paid,note FROM sales WHERE id=?",new String[]{""+id});
        if(!c.moveToFirst()){c.close();return;}String u=c.getString(0),dt=c.getString(1),note0=c.getString(4);long a0=c.getLong(2),p0=c.getLong(3);c.close();
        frame(s("সেল এডিট","Edit sale"));EditText date=field("YYYY-MM-DD",dt),amount=field(s("সেলের মোট টাকা","Sale amount"),""+a0),paid=field(s("প্রথম পেমেন্ট","Initial payment"),""+p0),note=field(s("নোট","Note"),note0);
        add(date);add(amount);add(paid);add(note);
        add(button(s("পরিবর্তন সংরক্ষণ","Save changes"),()->{long a=parse(amount.getText().toString()),p=parse(paid.getText().toString());String d=date.getText().toString().trim();
            if(a<=0||p<0||p>a||!validDate(d)){toast(s("সঠিক তথ্য দিন","Enter valid details"));return;}
            db.getWritableDatabase().execSQL("UPDATE sales SET sale_date=?,amount=?,initial_paid=?,note=? WHERE id=?",new Object[]{d,a,p,note.getText().toString().trim(),id});customerDetails(u);
        }));
    }
    void editPayment(int id,String u){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT pay_date,amount,note FROM payments WHERE id=?",new String[]{""+id});if(!c.moveToFirst()){c.close();return;}
        String d0=c.getString(0),n0=c.getString(2);long a0=c.getLong(1);c.close();
        frame(s("পেমেন্ট এডিট","Edit payment"));EditText date=field("YYYY-MM-DD",d0),amount=field(s("পেমেন্টের টাকা","Payment amount"),""+a0),note=field(s("নোট","Note"),n0);add(date);add(amount);add(note);
        add(button(s("পরিবর্তন সংরক্ষণ","Save changes"),()->{long a=parse(amount.getText().toString());String d=date.getText().toString().trim();long[] t=customerTotals(u);
            if(a<=0||!validDate(d)){toast(s("সঠিক তথ্য দিন","Enter valid details"));return;}
            if(a>a0+t[2]){toast(s("পেমেন্ট মোট বকেয়ার চেয়ে বেশি হবে","Payment exceeds allowable due"));return;}
            db.getWritableDatabase().execSQL("UPDATE payments SET pay_date=?,amount=?,note=? WHERE id=?",new Object[]{d,a,note.getText().toString().trim(),id});customerDetails(u);
        }));
    }
    void confirmDeleteSale(int id,String u){new AlertDialog.Builder(this).setMessage(s("এই সেলটি ডিলিট করবেন?","Delete this sale?")).setNegativeButton(s("না","Cancel"),null).setPositiveButton(s("ডিলিট","Delete"),(d,w)->{db.getWritableDatabase().execSQL("DELETE FROM sales WHERE id=?",new Object[]{id});customerDetails(u);}).show();}
    void confirmDeletePayment(int id,String u){new AlertDialog.Builder(this).setMessage(s("এই পেমেন্টটি ডিলিট করবেন?","Delete this payment?")).setNegativeButton(s("না","Cancel"),null).setPositiveButton(s("ডিলিট","Delete"),(d,w)->{db.getWritableDatabase().execSQL("DELETE FROM payments WHERE id=?",new Object[]{id});customerDetails(u);}).show();}
    void archiveCustomer(String u){new AlertDialog.Builder(this).setMessage(s("গ্রাহক আর্কাইভ করবেন? তথ্য থাকবে, তালিকা থেকে লুকানো হবে।","Archive customer? Data stays, hidden from active list.")).setNegativeButton(s("না","Cancel"),null).setPositiveButton(s("আর্কাইভ","Archive"),(d,w)->{db.getWritableDatabase().execSQL("UPDATE customers SET archived=1 WHERE username=?",new Object[]{u});showCustomers();}).show();}
    void deleteCustomer(String u){new AlertDialog.Builder(this).setMessage(s("স্থায়ীভাবে গ্রাহক ও তার সব সেল/পেমেন্ট মুছে যাবে। আগে ব্যাকআপ নিন।","This permanently deletes customer, sales and payments. Back up first.")).setNegativeButton(s("বাতিল","Cancel"),null).setPositiveButton(s("স্থায়ীভাবে ডিলিট","Delete permanently"),(d,w)->{SQLiteDatabase wdb=db.getWritableDatabase();wdb.execSQL("DELETE FROM sales WHERE username=?",new Object[]{u});wdb.execSQL("DELETE FROM payments WHERE username=?",new Object[]{u});wdb.execSQL("DELETE FROM customers WHERE username=?",new Object[]{u});showCustomers();}).show();}
    void backupMenu(){
        frame(s("ব্যাকআপ ও রিস্টোর","Backup & Restore"));
        add(text(s("JSON ফাইল এক্সপোর্ট করে নিরাপদ স্থানে রাখুন। রিস্টোর করলে বর্তমান হিসাব প্রতিস্থাপিত হবে।","Export a JSON backup and keep it safe. Restore replaces current records."),15,false));
        add(button(s("⬇ ব্যাকআপ এক্সপোর্ট","⬇ Export backup"),()->exportBackup()));
        add(button(s("⬆ ব্যাকআপ রিস্টোর","⬆ Restore backup"),()->pickBackup()));
    }
    void exportBackup(){
        try{
            JSONObject all=new JSONObject();JSONArray customers=new JSONArray(),sales=new JSONArray(),payments=new JSONArray();SQLiteDatabase r=db.getReadableDatabase();
            Cursor c=r.rawQuery("SELECT username,name,archived FROM customers",null);while(c.moveToNext()){JSONObject o=new JSONObject();o.put("username",c.getString(0));o.put("name",c.getString(1));o.put("archived",c.getInt(2));customers.put(o);}c.close();
            c=r.rawQuery("SELECT id,username,sale_date,amount,initial_paid,note FROM sales",null);while(c.moveToNext()){JSONObject o=new JSONObject();o.put("id",c.getInt(0));o.put("username",c.getString(1));o.put("date",c.getString(2));o.put("amount",c.getLong(3));o.put("paid",c.getLong(4));o.put("note",c.getString(5));sales.put(o);}c.close();
            c=r.rawQuery("SELECT id,username,pay_date,amount,note FROM payments",null);while(c.moveToNext()){JSONObject o=new JSONObject();o.put("id",c.getInt(0));o.put("username",c.getString(1));o.put("date",c.getString(2));o.put("amount",c.getLong(3));o.put("note",c.getString(4));payments.put(o);}c.close();
            all.put("format",1);all.put("customers",customers);all.put("sales",sales);all.put("payments",payments);
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"JihadBusinessManager-backup.json");startActivityForResult(i,501);
            pendingBackup=all.toString(2);
        }catch(Exception e){toast("Backup error: "+e.getMessage());}
    }
    String pendingBackup;
    void pickBackup(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,502);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;
        try{
            if(req==501&&pendingBackup!=null){java.io.OutputStream out=getContentResolver().openOutputStream(data.getData());out.write(pendingBackup.getBytes("UTF-8"));out.close();toast(s("ব্যাকআপ সেভ হয়েছে","Backup saved"));}
            else if(req==502){new AlertDialog.Builder(this).setMessage(s("বর্তমান সব হিসাব প্রতিস্থাপন হবে। চালিয়ে যাবেন?","Current records will be replaced. Continue?")).setNegativeButton(s("না","Cancel"),null).setPositiveButton(s("হ্যাঁ","Continue"),(d,w)->restore(data.getData()));new AlertDialog.Builder(this).setMessage(s("বর্তমান সব হিসাব প্রতিস্থাপন হবে। চালিয়ে যাবেন?","Current records will be replaced. Continue?")).setNegativeButton(s("না","Cancel"),null).setPositiveButton(s("হ্যাঁ","Continue"),(d,w)->restore(data.getData())).show();}
        }catch(Exception e){toast("Backup error: "+e.getMessage());}
    }
    void restore(android.net.Uri uri){try{
        java.io.InputStream in=getContentResolver().openInputStream(uri);java.io.ByteArrayOutputStream b=new java.io.ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)b.write(buf,0,n);in.close();
        JSONObject all=new JSONObject(new String(b.toByteArray(),"UTF-8"));JSONArray cs=all.getJSONArray("customers"),ss=all.getJSONArray("sales"),ps=all.getJSONArray("payments");
        SQLiteDatabase w=db.getWritableDatabase();w.beginTransaction();try{w.execSQL("DELETE FROM payments");w.execSQL("DELETE FROM sales");w.execSQL("DELETE FROM customers");
            for(int j=0;j<cs.length();j++){JSONObject o=cs.getJSONObject(j);w.execSQL("INSERT INTO customers(username,name,archived) VALUES(?,?,?)",new Object[]{o.getString("username"),o.optString("name",""),o.optInt("archived",0)});}
            for(int j=0;j<ss.length();j++){JSONObject o=ss.getJSONObject(j);w.execSQL("INSERT INTO sales(id,username,sale_date,amount,initial_paid,note) VALUES(?,?,?,?,?,?)",new Object[]{o.getInt("id"),o.getString("username"),o.getString("date"),o.getLong("amount"),o.getLong("paid"),o.optString("note","")});}
            for(int j=0;j<ps.length();j++){JSONObject o=ps.getJSONObject(j);w.execSQL("INSERT INTO payments(id,username,pay_date,amount,note) VALUES(?,?,?,?,?)",new Object[]{o.getInt("id"),o.getString("username"),o.getString("date"),o.getLong("amount"),o.optString("note","")});}
            w.setTransactionSuccessful();
        }finally{w.endTransaction();}toast(s("ব্যাকআপ রিস্টোর হয়েছে","Backup restored"));showHome();
        }catch(Exception e){toast(s("ব্যাকআপ ফাইল সঠিক নয়","Invalid backup file")+": "+e.getMessage());}}
    void toast(String msg){Toast.makeText(this,msg,Toast.LENGTH_LONG).show();}
    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"jihad_business.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE customers(username TEXT PRIMARY KEY,name TEXT,archived INTEGER DEFAULT 0)");
            d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL,sale_date TEXT NOT NULL,amount INTEGER NOT NULL,initial_paid INTEGER NOT NULL DEFAULT 0,note TEXT,FOREIGN KEY(username) REFERENCES customers(username))");
            d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL,pay_date TEXT NOT NULL,amount INTEGER NOT NULL,note TEXT,FOREIGN KEY(username) REFERENCES customers(username))");
        }
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
    }
}